

<b><p>The software used for drawing and coloring are: Inkscape. </b></p>
<b><p>Distributed with license Creative Commons (CC BY-SA 3.0) </b></p>
<b><p>If you like my work, buy me a Drink.</b></p>

<b><p>PayPal: https://www.paypal.me/ilnanny</b></p>


<b><p>Thank you</b></p>
