<b><br> == XFCE ARTWORK UNOFFICIAL == </b></br>

<b><br>The software used for drawing and coloring are: Inkscape. </b></br>
<b><br>Distributed with license Creative Commons (CC BY-SA 3.0) </b></br>
<b><br>If you like my work, buy me a Drink.</b></br>

<b><br>PayPal: https://www.paypal.me/ilnanny</b></br>
<b><br>Thank you</b></br>

